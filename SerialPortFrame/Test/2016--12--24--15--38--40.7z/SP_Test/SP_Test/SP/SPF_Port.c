

#include "SPF.h"
#include "usart.h"
#include "tim.h"

extern pSerialPortTypedef pSerialPort_1;

uint16_t PortTxData(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t Len)
{
    if(pSerialPort->ID == 0x01)
    {
        HAL_UART_Transmit_IT(&huart1,Data,Len);
    }
	return (uint16_t)Res_OK;
}

uint16_t PortRxData(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t Len)
{
    if(pSerialPort->ID == 0x01)
    {
		HAL_UART_Receive_IT(&huart1,Data,Len);
    }
	return (uint16_t)Res_OK;
}

uint16_t UsartInit(pSerialPortTypedef pSerialPort)
{
    if(pSerialPort->ID == 0x01)
    {
		MX_USART1_UART_Init();
		MX_TIM1_Init();
		__HAL_TIM_CLEAR_IT(&htim1, TIM_IT_UPDATE);
		HAL_TIM_Base_Start_IT(&htim1);
    }
	return (uint16_t)Res_OK;
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART1)
	{
		 FuncRxIntHook(pSerialPort_1);
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == USART1)
	{
		 FuncTxIntHook(pSerialPort_1);
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM1)
	{
		FuncTickHook(pSerialPort_1,10);
	}
}







