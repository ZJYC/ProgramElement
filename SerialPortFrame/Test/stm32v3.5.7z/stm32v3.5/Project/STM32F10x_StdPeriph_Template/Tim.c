/*
****************************************************
*  �ļ���             : 
*  ����               : -5A4A5943-
*  �汾               : 
*  ��д����           : 
*  ���               : 
*  �����б�           : 
*  ��ʷ�汾           : 
*****************************************************
*/


/*ͷ�ļ�  */

#include "stm32f10x.h"



/*�궨��  */





/*��������*/





/*��������*/





/*��������*/

void TimeInit(void)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
    
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3,ENABLE);  
    TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
    TIM_TimeBaseStructure.TIM_Period = 10000;//Ƶ�ʣ�72MHz  72000000/36000=2000
    TIM_TimeBaseStructure.TIM_Prescaler = 71;//36000-1=35999
    TIM_TimeBaseStructure.TIM_ClockDivision = 0x0;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);
    TIM_ITConfig(TIM3, TIM_IT_Update, ENABLE );
    TIM_Cmd(TIM3,ENABLE);  

    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;  
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 1;  
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
    NVIC_Init(&NVIC_InitStructure);  

}






















