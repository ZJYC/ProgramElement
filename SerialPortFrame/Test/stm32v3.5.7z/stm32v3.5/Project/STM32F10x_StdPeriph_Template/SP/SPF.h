
#ifndef __SPF_H__
#define __SPF_H__
/*
****************************************************
*  文件名             : 
*  作者               : -5A4A5943-
*  版本               : 
*  编写日期           : 
*  简介               : 
*  函数列表           : 
*  历史版本           : 
*****************************************************
*/


/*头文件  */

#include <string.h>
//#include "stm32f1xx_hal.h"
#include "stm32f10x.h"
#include "heap_5.h"
#include "ringbuffer.h"
#include "assert.h"

/*宏定义  */

/* 定义滴答的最大值，必须为循环计数 */
#define TickFull    (1000000)
/* 获取两个滴答之间的间隔 */
#define GetInterval(Cur,Last)   ((Cur) >= (Last) ? ((Cur) - (Last)) : (TickFull - (Last) + (Cur)))
/* 递增 */
#define TickAdd(val,add)            {\
                                    (val) += (add);\
                                    if((val) > TickFull)(val) = 0;\
                                    }


/*变量定义*/

typedef enum SP_ResTypedef_
{
    Res_OK = 0,                 /*  */
    Res_NoData2Send = 1,
    Res_SendNotAllowes = 2,
    Res_NowTxing = 3,
    Res_TxFinished = 4,
    Res_TxTimeout = 5,
    Res_NowRxing = 6,
    Res_RxTimeout = 7,
    Res_RxDataHaveRecv = 8,
    Res_RxNotAllowed = 9,
    Res_AutoClosed = 10,
    Res_RxInterval = 11,
    Res_False = 12,
    Res_ParamError = 13,
    Res_TxWaiting = 14,
    
    Res_Reserve = 1000
}SP_ResTypedef;

typedef struct SpanSendTypedef_
{
    
    uint32_t SN;    /* 序列号 */
    uint16_t Len;   /* 长度 */
    uint16_t Span;  /* 间隔 */
    
}SpanSendTypedef;

typedef struct SerialPortTypedef_
{
    uint32_t    ID;
    //////////////////////////////////////////////////////////////////////
    /* 接收与发送缓冲 */
    Ringbuff_t  RxRB;
    Ringbuff_t  TxRB;
    uint32_t    LastRxTime;
    uint32_t    LastTxTime;
    uint32_t    RxInterval;
    union  
    {
        struct 
        {
            uint32_t RxFin      :   1;/* 接收完成标志 */
            uint32_t TxFin      :   1;/* 发送完成标志 */
            uint32_t RxEn       :   1;/* 允许接收数据 */
            uint32_t TxEn       :   1;/* 允许发送数据 */
            uint32_t Retried    :   1;/* 表明发生重传 */
            uint32_t Txing      :   1;/* 正在发送 */
            uint32_t Rxing      :   1;/* 正在接收中 */
            uint32_t AutoCloseRx:   1;/* 自动关闭接收 */
            uint32_t TxWaiting  :   1;/* 发送正在等待（间隔发送） */
        }bit;
        uint32_t bits;
    }u;
    uint32_t Counter;
    uint8_t RxTemp;
    SpanSendTypedef SpanSend;
    uint32_t SN;
}SerialPortTypedef,*pSerialPortTypedef;

/*  */
uint16_t LowerLayerPrapareRx(pSerialPortTypedef pSerialPort);
/* 发送数据，返回发送的数据长度 */
uint16_t LowerLayerTxFirstByte(pSerialPortTypedef pSerialPort);
/* 串口初始化 */
uint16_t LowerLayerInit(pSerialPortTypedef pSerialPort);
/* 回调函数 */

/* 定时回调 */
uint16_t FuncTickHook(pSerialPortTypedef pSerialPort,uint16_t Period);
/* 接收中断回调 */
uint16_t FuncRxIntHook(pSerialPortTypedef pSerialPort);
/* 发送中断回调 */
uint16_t FuncTxIntHook(pSerialPortTypedef pSerialPort);
/* 容错/保障/自动 */
uint16_t AutoAdopt(pSerialPortTypedef pSerialPort);
/* 用户接口 */
pSerialPortTypedef SP_Init(uint32_t ID,uint32_t RxBuffSize,uint32_t TxBuffLen);
uint16_t SP_Send(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t TxLen,uint16_t Span,uint16_t Timeout);
uint16_t SP_Recv(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t *MaxLen,uint16_t Timeout);

uint16_t PortInit(pSerialPortTypedef pSerialPort);
uint16_t PortRxData(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t Len);
uint16_t PortTxData(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t Len);


void SPF_Delay(uint32_t Cnt);

/*变量声明*/



/*函数声明*/





#endif













































