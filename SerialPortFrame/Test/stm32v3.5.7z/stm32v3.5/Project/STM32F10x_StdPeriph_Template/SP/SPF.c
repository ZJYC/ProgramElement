/* 
        为什么写这个？
        我可不想每次都重新写一个串口驱动，************，所以想写一个串口驱动的框架，受STM32_HAL
        的启发，使用控制块+ID的方式使得驱动能够适用于多串口的情况，将来，也会应用于SPI等串行接
        口上，他们本质是相同的。受FreeRTOS-TCP/IP的启发，使用u.bit.xxx的标志位来记录事件（在这
        里特别说明一下，TCP/IP写的不错，最起码他让我头疼了很长时间，最后还是一脸懵）用了个内存
        管理算法（FreeRTOS的heap_5），就是感觉好玩。
        怎么用？
        首先说我自己都感觉不好用，我想把驱动写的层次分明，但是功底不够，写出来渣得很，就留给自
        己以后用吧，尔等不怕麻烦的可以用。
        用户层接口：
                    SP_Init
                    SP_Send
                    SP_Recv
                    
                    根据指定的参数，SP_Init返回SP控制块，此控制块会作为参数用在SP_Send和SP_Recv
                    上
        底层接口层：
                    PortTxData          发送数据
                    PortRxData          接收数据
                    PortInit            初始化底层
                    
                    一个重要的问题，本驱动可以用在多个串口的情况，每一个串口使用一个SP控制块，
                    然而驱动接口只有一个，如何区分是哪一个串口需要初始化呢？答：SP_Init传入的
                    ID号
        回调函数接口：
                    FuncRxIntHook
                    接收到数据之后需要调用次函数，并传入对应的SP控制块
                    FuncTxIntHook
                    同上
                    FuncTickHook
                    定时中断中要调用此函数，并传入定时周期
                    
                    



 */
 
 /* 2016--12--30--16--31--30 */
 /* 期望增加间隔发送功能，因为有些设备可能不用硬件流控，只通过实践或者是协议来判别，我们这里可以增加间隔发送的功能 */
 /* 想法：在缓冲区中存入多余的数据 SN(2B) + Len(2B) + Interval(2B) */
 
#include "SPF.h"
/* 声明一个4096字节的数组 */
static uint32_t SP_Pool[1024] = {0x00};
/* 提供给内存分配 */
static HeapRegion_t xHeapRegions[] =
{
    {(uint8_t *)SP_Pool,4096},
    { NULL, 0 }
};

uint16_t LowerLayerInit(pSerialPortTypedef pSerialPort);
uint16_t LowerLayerTxFirstByte(pSerialPortTypedef pSerialPort);
uint16_t LowerLayerPrapareRx(pSerialPortTypedef pSerialPort);

void SPF_Delay(uint32_t Cnt)
{
    while(Cnt--);
}

/*
****************************************************
*  函数名         : SP_Init
*  函数描述       : SP初始化
                    后期的发送/接收驱动只是传递SP控制块，只能通过ID进行区分
*  参数           : 
                    ID：每一个SP控制块用ID进行识别，后期会有用处
                    RxBuffSize：接收缓冲大小，暂时认为不能为0
                    TxBuffLen：发送缓冲长度，暂时认为不能为0
*  返回值         : 失败返回0
*  作者           : -5A4A5943-
*  历史版本       : 
*****************************************************
*/
pSerialPortTypedef SP_Init(uint32_t ID,uint32_t RxBuffSize,uint32_t TxBuffLen)
{
    pSerialPortTypedef SerialPortTemp = 0x00;
    /* 内存分配初始化 */
    MM_Ops.Init(xHeapRegions);
    /* 申请SP控制块 */
    SerialPortTemp = (pSerialPortTypedef)MM_Ops.Malloc(sizeof(SerialPortTypedef));
    if(SerialPortTemp == 0)return 0;
    memset((void*)SerialPortTemp,'\0',sizeof(SerialPortTypedef));
    /* 申请接受缓冲区 */
    if(RxBuffSize != 0)
    {
        SerialPortTemp->RxRB.buffer = MM_Ops.Malloc(RxBuffSize);
        if(SerialPortTemp->RxRB.buffer == 0)return 0;
        memset((void*)SerialPortTemp->RxRB.buffer,'\0',RxBuffSize);
        SerialPortTemp->RxRB.size = RxBuffSize;
        RB_FUNC.Init(&SerialPortTemp->RxRB);
    }
    /* 申请发送缓冲区 */
    if(TxBuffLen != 0)
    {
        SerialPortTemp->TxRB.buffer = MM_Ops.Malloc(TxBuffLen);
        if(SerialPortTemp->TxRB.buffer == 0)return 0;
        memset((void*)SerialPortTemp->TxRB.buffer,'\0',TxBuffLen);
        SerialPortTemp->TxRB.size = TxBuffLen;
        RB_FUNC.Init(&SerialPortTemp->TxRB);
    }
    /* 填写ID */
    SerialPortTemp->ID = ID;
    /* 假定发送流间隔为30ms */
    SerialPortTemp->RxInterval = 30;
    SerialPortTemp->SN = 0x1234;
    /* 底层初始化：串口、定时器等 */
    LowerLayerInit(SerialPortTemp);
    return SerialPortTemp;
}

/*
****************************************************
*  函数名         : SP_Send
*  函数描述       : 发送数据
*  参数           : 
                    pSerialPort：SP控制块
                    Data：数据地址
                    TxLen：发送数据长度
                    Span：发送完成数据之后，串口需要等待多长时间
                    Timeout：超时（如果缓冲区满了，我们要等待直到有足够的空间来存储，否则超时）
*  返回值         : 
                    Res_OK：OK
                    Res_TxTimeout：一直到超时都没有足够的空间来存储数据
*  作者           : -5A4A5943-
*  历史版本       : 
*****************************************************
*/
uint16_t SP_Send(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t TxLen,uint16_t Span,uint16_t Timeout)
{
    uint16_t WriteLen = 0;
    SpanSendTypedef SpanSend = {0x00};
    /* 执行参数检查 */
    assert(pSerialPort);
    assert(Data);
    /* SN(2B) + Len(2B) + Interval(2B) 不一定等于6 视编译器而定 */
    WriteLen = TxLen + sizeof(SpanSendTypedef);
    
    SpanSend.SN = pSerialPort->SN;
    pSerialPort->SN += TxLen;
    if(pSerialPort->SN > 100000)pSerialPort->SN = 0x1234;
    
    SpanSend.Len = TxLen;
    SpanSend.Span = Span;
    
    /* 记录当前时间 以备超时检查*/
    pSerialPort->LastTxTime = pSerialPort->Counter;
    TxWaitRB:
    /* 如果缓冲区足够，保存返回成功 */
    if(RB_FUNC.Available(&pSerialPort->TxRB) >= WriteLen)
    {
        RB_FUNC.Write(&pSerialPort->TxRB,(uint8_t * )&SpanSend,sizeof(SpanSendTypedef));
        RB_FUNC.Write(&pSerialPort->TxRB,Data,TxLen);
        /* 使能发送 并尝试发送第一个字节 */
        pSerialPort->u.bit.TxEn = 1;
        LowerLayerTxFirstByte(pSerialPort);
        return (uint16_t)Res_OK;
    }
    /* 缓存区并不充足，极有可能是正在发送中，等待缓冲区腾出空间 */
    /*2016--12--24--22--30--05(ZJYC): need test   */ 
    while(GetInterval(pSerialPort->Counter,pSerialPort->LastTxTime) < Timeout)goto TxWaitRB;
    return (uint16_t)Res_TxTimeout;
}

/*
****************************************************
*  函数名         : SP_Recv
*  函数描述       : 接收数据
*  参数           : 
                    pSerialPort：控制块
                    Data：数据缓冲
                    MaxLen：期望接受长度（为0表示用户不指定数据长度，直接返回缓冲区的所有字节即可
                    如果此时缓冲区没有数据，则会启动接收数据，超时退出）
                    Timeout：超时
*  返回值         : 
                    Res_OK：OK
                    Res_NowRxing：现在正在发送呢
                    Res_RxTimeout：超时
                    Res_False：不知原因、、失败了
*  作者           : -5A4A5943-
*  历史版本       : 
*****************************************************
*/
uint16_t SP_Recv(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t *MaxLen,uint16_t Timeout)
{
    assert(pSerialPort);
    assert(Data);
    /* 串口正在接收数据流 不允许操作 */
    if(pSerialPort->u.bit.Rxing == 1){*MaxLen = 0;return (uint16_t)Res_NowRxing;}
    /* 如果指定了数据长度 并且 RB有足够的数据 */
    if((*MaxLen != 0) && RB_FUNC.Used(&pSerialPort->RxRB) >= *MaxLen)
    {
        RB_FUNC.Read(&pSerialPort->RxRB,Data,*MaxLen);
        return Res_OK;
    }
    /* RB显然没有足够的数据 */
    if((*MaxLen != 0) && RB_FUNC.Used(&pSerialPort->RxRB) < *MaxLen)
    {
        LowerLayerPrapareRx(pSerialPort);
        /* 没有探测到字符流则等待Timeout */
        while(GetInterval((pSerialPort->Counter),(pSerialPort->LastRxTime)) < Timeout)
        {
            /* 探测到字符流 */
            if(pSerialPort->u.bit.Rxing == 1)
            {
                break;
            }
        }
        if(GetInterval(pSerialPort->Counter,pSerialPort->LastRxTime) >= Timeout)
        {
            *MaxLen = 0;
            return (uint16_t)Res_RxTimeout;
        }
        /* 字符流接收完成 */
        /* 这里我们认为字符流肯定会有结束 */
        //////////////////////////////////////
        /* 这里隐藏一很严重的隐患，程序会死在这里 */
        //////////////////////////////////////
        while(pSerialPort->u.bit.RxFin == 0);
        pSerialPort->u.bit.RxFin = 0;
        /* 依然没有收到调用者期望的数据长 */
        if(RB_FUNC.Used(&pSerialPort->RxRB) < *MaxLen)
        {
            *MaxLen = 0;
            return (uint16_t)Res_RxTimeout;
        }
        /* 符合调用者的要求 */
        else
        {
            RB_FUNC.Read(&pSerialPort->RxRB,Data,*MaxLen);
            pSerialPort->u.bit.RxFin = 0;
            return Res_OK;
        }
    }
    /* 调用者不指定接受长度 */
    if(*MaxLen == 0)
    {
        uint16_t RxLen = RB_FUNC.Used(&pSerialPort->RxRB);
        /* 当前有数据可以直接取出  并且数据流已经断开 */
        if(RxLen != 0 && pSerialPort->u.bit.Rxing != 1)
        {
            RB_FUNC.Read(&pSerialPort->RxRB,Data,RxLen);
            pSerialPort->u.bit.RxFin = 0;
            *MaxLen = RxLen;
            return Res_OK;
        }
        if(pSerialPort->u.bit.Rxing == 1)
        {
            /* 等待直到数据流停止 */
            while(pSerialPort->u.bit.RxFin == 0);
            pSerialPort->u.bit.RxFin = 0;
            RxLen = RB_FUNC.Used(&pSerialPort->RxRB);
            RB_FUNC.Read(&pSerialPort->RxRB,Data,RxLen);
            *MaxLen = RxLen;
            return Res_OK;
        }
        /* 缓冲区没有数据 && 当前不在发送状态 -> 启动发送 知道 收到数据 || 超时 */
        if(RxLen == 0 && pSerialPort->u.bit.Rxing == 0)
        {
            LowerLayerPrapareRx(pSerialPort);
            /* 如果在制定时间之内没有探测到字符流->返回超时 */
            while(GetInterval((pSerialPort->Counter),(pSerialPort->LastRxTime)) < Timeout)
            {
                /* 探测到字符流 */
                if(pSerialPort->u.bit.Rxing == 1)
                {
                    break;
                }
            }
            if(GetInterval(pSerialPort->Counter,pSerialPort->LastRxTime) >= Timeout)return (uint16_t)Res_RxTimeout;
            /* 等待接收完成 */
            while(pSerialPort->u.bit.RxFin == 0);
            pSerialPort->u.bit.RxFin = 0;
            RxLen = RB_FUNC.Used(&pSerialPort->RxRB);
            if(RxLen != 0)RB_FUNC.Read(&pSerialPort->RxRB,Data,RxLen);
            *MaxLen = RxLen;
            return Res_OK;
        }
    }
    return Res_False;
}

/*
****************************************************
*  函数名         : LowerLayerPrapareRx
*  函数描述       : 开始准备接收
*  参数           : pSerialPort：控制块
*  返回值         : 
                    Res_OK：
*  作者           : -5A4A5943-
*  历史版本       : 
*****************************************************
*/
uint16_t LowerLayerPrapareRx(pSerialPortTypedef pSerialPort)
{
    /* 允许中断接收数据 */
    pSerialPort->u.bit.RxEn = 1;
    pSerialPort->u.bit.Rxing = 0;
    /* 记录时间 */
    pSerialPort->LastRxTime = pSerialPort->Counter;
    PortRxData(pSerialPort,&pSerialPort->RxTemp,1);
    return Res_OK;
}

/*
****************************************************
*  函数名         : LowerLayerTxFirstByte
*  函数描述       : 发送第一字节数据
*  参数           : pSerialPort：控制块
*  返回值         : 
                    Res_OK：
                    Res_NoData2Send：
                    Res_NowTxing：
                    Res_SendNotAllowes：
*  作者           : -5A4A5943-
*  历史版本       : 
*****************************************************
*/
/*  1：当前没有数据等待发送    TxWaiting = 0
    2：当前有数据正在发送     Txing = 1
    4：数据发送未使能*/
uint16_t LowerLayerTxFirstByte(pSerialPortTypedef pSerialPort)
{
    uint8_t Temp = 0;
    
    assert(pSerialPort);
    
    if(pSerialPort->u.bit.TxEn == 1)
    {
        /* 当前有数据正在等待发送 */
        if(pSerialPort->u.bit.TxWaiting == 1)
        {
            return (uint16_t)Res_TxWaiting;
        }
        /* 当前没有字节流在发送 */
        if(pSerialPort->u.bit.Txing == 0)
        {
            pSerialPort->u.bit.Txing = 1;
            /* 有数据存储在RB */
            if(RB_FUNC.Used(&pSerialPort->TxRB) != 0)
            {
                /* 读取出控制块 */
                RB_FUNC.Read(&pSerialPort->TxRB,(uint8_t *)&pSerialPort->SpanSend,sizeof(SpanSendTypedef));
                /* 预算SN数 */
                pSerialPort->SpanSend.SN += pSerialPort->SpanSend.Len;
                /* 取出一个数据 */
                pSerialPort->SpanSend.Len -= 1;
                /* 读取一字节数据 */
                RB_FUNC.Read(&pSerialPort->TxRB,&Temp,1);
                /* 发送数据 */
                PortTxData(pSerialPort,&Temp,1);
                return (uint16_t)Res_OK;
            }
            /* 没有数据可以发送 */
            else
            {
                pSerialPort->u.bit.TxWaiting = 0;
                pSerialPort->u.bit.Txing = 0;
                pSerialPort->u.bit.TxEn = 0;
                return (uint16_t)Res_NoData2Send;
            }
        }
        else
        {
            return (uint16_t)Res_NowTxing;
        }
    }
    return (uint16_t)Res_SendNotAllowes;
}



/*
****************************************************
*  函数名         : LowerLayerInit
*  函数描述       : 初始化底层接口
*  参数           : pSerialPort：控制块
*  返回值         : 
                    Res_OK：
*  作者           : -5A4A5943-
*  历史版本       : 
*****************************************************
*/
uint16_t LowerLayerInit(pSerialPortTypedef pSerialPort)
{
    PortInit(pSerialPort);
    return (uint16_t)Res_OK;
}















