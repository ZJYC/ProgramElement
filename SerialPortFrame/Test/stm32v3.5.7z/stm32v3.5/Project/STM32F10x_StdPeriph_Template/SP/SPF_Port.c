
/*
****************************************************
*  文件名             : SPF_Port.c
*  作者               : -5A4A5943-
*  版本               : V1.0
*  编写日期           : 2017--01--12--11--00--42
*  简介               : SP's interface which implemented by user
*  函数列表           : 
                        LowLayerPort_TxData     Let Low layer send data
                        LowLayerPort_RxData     Let Loe layer recv data
                        LowLayerPort_Init       Init the low layer
*  历史版本           : 
*****************************************************
*/

#include "SPF.h"

extern pSerialPortTypedef pSerialPort_1;

/* 
    the following are the ports that you need to implement based on your hardware 
    Use ID to compatible more than one hardware,Because The control information was 
    storaged in pSerialPort.
    
*/

uint16_t LowLayerPort_TxData(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t Len)
{
    if(pSerialPort->ID == 0x01)
    {
        USART_SendData(USART1, Data[0]);
    }
    return (uint16_t)Res_OK;
}

uint16_t LowLayerPort_RxData(pSerialPortTypedef pSerialPort,uint8_t * Data,uint16_t Len)
{
    if(pSerialPort->ID == 0x01)
    {
        Data[0] = USART_ReceiveData(USART1);
    }
    return (uint16_t)Res_OK;
}

uint16_t LowLayerPort_Init(pSerialPortTypedef pSerialPort)
{
    if(pSerialPort->ID == 0x01)
    {
        UsartInit();
        TimeInit();
    }
    return (uint16_t)Res_OK;
}

/* 
    The following are something except for interface,Here,I use ST's framework V3.5,
    So I add the interrupt handle here
*/

void USART1_IRQHandler(void)
{  
    if(USART_GetFlagStatus(USART1, USART_FLAG_ORE) != RESET)
    {
        
    }
    if(USART_GetITStatus(USART1, USART_IT_RXNE) != RESET)
    {
        USART_ClearITPendingBit(USART1,USART_IT_RXNE);
        //USART_ReceiveData(USARTy)
        SP_RxIntProcess(pSerialPort_1);
    }
    
    if(USART_GetITStatus(USART1, USART_IT_TC) != RESET)
    {
        USART_ClearITPendingBit(USART1,USART_IT_TC);
        //USART_SendData(USARTy, TxBuffer1[TxCounter1++]);
        SP_TxIntProcess(pSerialPort_1);
    }
}

void TIM3_IRQHandler(void)
{
    TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
    SP_TimingIntProcess(pSerialPort_1,1);
}



