
#ifndef _DES_H__
#define _DES_H__

#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#include "stm32f1xx_hal.h"

#define ENCRYPT     'e'
#define DECRYPT     'd'


















#endif



